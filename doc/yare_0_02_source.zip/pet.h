// ADDED on 04/09/2003 ------------
int pet_init(struct map_session_data *sd);
int pet_store_init_npc_id(int *id);
// --------------------------------
