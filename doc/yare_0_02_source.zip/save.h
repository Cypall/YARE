int mmo_char_GM(struct map_session_data *sd);
void mmo_char_save(struct map_session_data *sd);
