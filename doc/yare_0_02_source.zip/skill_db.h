unsigned long search_placeskill(int skill_id);
struct skill_db skill_database(int i_skill_id);
int search_database(void);
