int mmo_char_GM(int fd);
int search_empty_ID(long int object);
void mmo_char_save(int fd);
int parse_frommap(int fd);
