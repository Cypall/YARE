int create_guild(int fd,unsigned char *dat);

