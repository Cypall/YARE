unsigned char* parse_script(unsigned char *src);
int run_script(int fd,struct map_session_data *sd);
