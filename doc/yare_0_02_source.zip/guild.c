#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
	
#include "guild.h"
#include "mmo.h"
#include "core.h"

int create_guild(int fd,unsigned char *dat){
	return 0;
}

